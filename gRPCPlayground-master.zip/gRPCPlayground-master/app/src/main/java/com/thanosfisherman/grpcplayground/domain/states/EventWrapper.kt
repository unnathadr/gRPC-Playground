package com.thanosfisherman.grpcplayground.domain.states

/**
 * Used as a wrapper for data that is exposed via a LiveData/StateFlow that represents an single-shot event.
 */
open class EventWrapper<out T>(private val content: T) {

    var hasBeenHandled = false
        private set // Allow external read but not write

    /**
     * Returns the content and prevents its use again.
     */
    fun getContentIfNotHandled(): T? {
        return if (hasBeenHandled) {
            null
        } else {
            hasBeenHandled = true
            content
        }
    }

    /**
     * Returns the content, even if it's already been handled.
     */
    fun peekContent(): T = content
}